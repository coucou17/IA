#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h> 
#include "incrocio.h"

/*
 Ogni processo automobile:

 1. Attende il permesso dal processo incrocio

 2. Attraversa l'incrocio

 3. Scrive su auto.txt la strada di provenienza

 4. Comunica a incrocio l'avvenuto attraversamento
 
 5. Termina correttamente
*/





// Variabile globale usata per gestire la terminazione sicura tramite segnale
static volatile sig_atomic_t termina = 0;

// Nomi base dei semafori per la comunicazione auto/incrocio 
static const char *SEM_PERMISSION_BASE = "/sem_auto_permission_";
static const char *SEM_CONFIRMATION_BASE = "/sem_auto_confirmation_";


// Gestore del segnale SIGTERM
// Imposta la variabile termina per indicare che il processo deve terminare
void gestore_sigterm(int signo) {
    (void)signo;        // Evita warning sul parametro non utilizzato
    termina = 1;        // Segnala la richiesta di terminazione
}

int main(int argc, char *argv[]) {

    // Controllo del numero di argomenti passati al programma
    // Devono essere: nome_programma, provenienza, destinazione
    if (argc != 3) {
        fprintf(stderr, "[Auto] Usage: %s <provenance> <destination>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

     // Conversione degli argomenti da stringa a intero
    int provenienza = atoi(argv[1]);
    int destinazione = atoi(argv[2]);
    int id = provenienza;  

    /* Installazione del gestore del segnale SIGTERM */
    struct sigaction sa;
    sa.sa_handler = gestore_sigterm;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    // Associa il gestore al segnale SIGTERM
    if (sigaction(SIGTERM, &sa, NULL) == -1) {
        perror("[Auto] sigaction");
        exit(EXIT_FAILURE);
    }
    
    /* Apertura dei semafori */
    char name_perm[64], name_conf[64];
    sprintf(name_perm, "%s%d", SEM_PERMISSION_BASE, id);
    sprintf(name_conf, "%s%d", SEM_CONFIRMATION_BASE, id);

    // Apertura del semaforo di permesso (già creato da incrocio)
    sem_t *sem_permission = sem_open(name_perm, 0);

    // Apertura del semaforo di conferma
    sem_t *sem_confirmation = sem_open(name_conf, 0);


    // Controllo errori nell'apertura dei semafori
    if (sem_permission == SEM_FAILED || sem_confirmation == SEM_FAILED) {
        perror("[Auto] sem_open");
        exit(EXIT_FAILURE);
    }


    /* Attesa del permesso da incrocio */
    // sem_wait blocca il processo finché incrocio non concede il permesso
    while (sem_wait(sem_permission) == -1) {
        // Se sem_wait è stato interrotto da un segnale
       if (errno == EINTR && termina)
           goto cleanup;  // Uscita controllata per pulizia risorse
    }





    // Messaggio informativo sull'attraversamento
    printf("\n[Auto %d] Attraverso da %d a %d\n", id, provenienza, destinazione);
    sleep(1); 

    /* Scrittura su auto.txt */
    // Apertura del file in scrittura, creazione se non esiste, append in fondo
    int fd_file = open("auto.txt", O_WRONLY | O_CREAT | O_APPEND, 0666);
    if (fd_file == -1) {
        perror("[Auto] open auto.txt");
        goto cleanup;
    }

    // Buffer per la scrittura della provenienza
    char buffer[16];

    // Scrive la provenienza come testo nel buffer
    int len = snprintf(buffer, sizeof(buffer), "%d\n", provenienza);
    if (write(fd_file, buffer, len) != len) {
        perror("[Auto] write auto.txt");
        close(fd_file);
        goto cleanup;
    }

    close(fd_file);

    /* Comunicazione a incrocio */
    // Incrementa il semaforo per segnalare che l'auto ha attraversato
    sem_post(sem_confirmation);

    // Messaggio di fine attraversamento
    printf("[Auto %d] Attraversamento completato, termino.\n\n", id);

cleanup:
    // Chiusura dei semafori per evitare perdite di risorse
    sem_close(sem_permission);
    sem_close(sem_confirmation);
    
    return EXIT_SUCCESS;
}
