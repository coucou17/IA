#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include "incrocio.h"

#define NUM_AUTO 4            // Numero di automobili create in ogni round


static volatile sig_atomic_t termina = 0;


// Gestore del segnale SIGTERM
void gestore_sigterm(int signo) {
    (void)signo;        
    termina = 1;
}

// Array per memorizzare i PID delle automobili create
pid_t pid_auto[NUM_AUTO];


int main(void) {
    srand(time(NULL));


    /* Gestore SIGTERM */
    struct sigaction sa;
    sa.sa_handler = gestore_sigterm;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    // Associa il gestore al segnale SIGTERM
    if (sigaction(SIGTERM, &sa, NULL) == -1) {
        perror("[Garage] sigaction");
        exit(EXIT_FAILURE);
    }


    /* Scrittura del PID del garage su file */
    // Serve a incrocio per sapere quale processo terminare
    FILE *fp = fopen("garage.pid", "w");
    if (!fp) {
          perror("[Garage] fopen garage.pid");
          exit(EXIT_FAILURE);
    }
     
    // Scrive il PID del processo garage nel file
          fprintf(fp, "%d\n", getpid());
          fclose(fp);

    // Nome della FIFO utilizzata per notificare incrocio
    const char *fifo_notifica = "fifo_garage_to_incrocio";

    /* Attesa passiva finché incrocio non crea la FIFO */
    while (access(fifo_notifica, F_OK) == -1) {
        if (termina) exit(EXIT_SUCCESS);       // Termina se riceve SIGTERM
        sleep(1);                             
    }

    int round = 1;                             // Contatore dei round di simulazione




    while (!termina) {
        printf("\n[Garage] Round %d: creo 4 automobili\n", round);

        // Array per memorizzare le direzioni delle automobili
        int direzioni[NUM_AUTO];

        /*  Creazione dei processi automobili  */
        for (int i = 0; i < NUM_AUTO; i++) {

            int provenienza = i;              // Strada di provenienza
            int destinazione = EstraiDirezione(provenienza);
            direzioni[i] = destinazione;       // Salva la direzione

            printf("  -> Auto %d: da %d a %d\n", i, provenienza, destinazione);

            // Creazione del processo figlio
            pid_t pid = fork();
            if (pid < 0) {
                perror("[Garage] fork");
                exit(EXIT_FAILURE);
            }

            if (pid == 0) {
                /* Processo automobile */

                // Conversione degli argomenti in stringa
                char prov[8], dest[8];
                snprintf(prov, sizeof(prov), "%d", provenienza);
                snprintf(dest, sizeof(dest), "%d", destinazione);

                // Sostituisce il processo figlio con il programma automobile
                execl("./automobile", "automobile", prov, dest, (char *)NULL);

                perror("[Garage] execl automobile");  
                exit(EXIT_FAILURE);
            }

            // Salva il PID dell'automobile nel processo padre
            pid_auto[i] = pid;
        }

        /* Notifica a incrocio che ci sono 4 automobili */
        // Apre la FIFO in scrittura
        
        int fd = open(fifo_notifica, O_WRONLY);
        if (fd == -1) {
            perror("[Garage] open fifo_notifica");
            exit(EXIT_FAILURE);
        }

        // Scrive l'array delle direzioni sulla FIFO
        if (write(fd, direzioni, sizeof(direzioni)) != sizeof(direzioni)) {
            perror("[Garage] write fifo_notifica");
            close(fd);
            exit(EXIT_FAILURE);
        }
        close(fd);

        /* Attesa terminazione automobili */
        for (int i = 0; i < NUM_AUTO; i++) {
            waitpid(pid_auto[i], NULL, 0);
        }

        sleep(1);          
        round++;
    }



    /* Attende la terminazione di eventuali automobili ancora attive */

    for (int i = 0; i < NUM_AUTO; i++) {
        if (pid_auto[i] > 0) {
        waitpid(pid_auto[i], NULL, 0);
    }
}


    return EXIT_SUCCESS;
}


