PROGETTO "INCROCIO" – SISTEMI OPERATIVI CON LABORATORIO

Il progetto è corredato da uno script Bash (start.sh) che consente di compilare
e avviare automaticamente l’applicazione.

Il codice sorgente è commentato in modo da facilitarne la comprensione,
descrivendo il ruolo dei processi e le scelte di sincronizzazione adottate.

L’applicazione non richiede l’esecuzione con privilegi di root per il suo
funzionamento ed è conforme ai requisiti richiesti dall’ambiente Unix/Linux.
