#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/wait.h>
#include <semaphore.h> 
#include "incrocio.h"


#define NUM_AUTO 4




static volatile sig_atomic_t termina = 0;

// PID del garage 
static pid_t pidGarage = -1;


// FIFO usata per la comunicazione garage → incrocio
static const char *fifoGarageToIncrocio = "fifo_garage_to_incrocio";


// Nomi base dei semafori per la sincronizzazione auto/incrocio 
static const char *SEM_PERMISSION_BASE = "/sem_auto_permission_";
static const char *SEM_CONFIRMATION_BASE = "/sem_auto_confirmation_";

/* Puntatori ai semafori */
sem_t *sem_permissions[NUM_AUTO];
sem_t *sem_confirmations[NUM_AUTO];

static int direzioni[NUM_AUTO];

void gestore_sigterm(int signo) {
    (void)signo;
    termina = 1;
}

// Pulizia delle risorse
void cleanup_resources(void) {
    unlink(fifoGarageToIncrocio); // Rimuove la FIFO principale dal filesystem
    unlink("garage.pid");  // Rimuove il file contenente il PID del garage


    // Chiusura e rimozione dei semafori POSIX
    for (int i = 0; i < NUM_AUTO; i++) {

        if (sem_permissions[i] != SEM_FAILED) {
            sem_close(sem_permissions[i]);
            // Chiude il semaforo di permesso

            char name[64];
            sprintf(name, "%s%d", SEM_PERMISSION_BASE, i);
            sem_unlink(name);
             // Rimuove definitivamente il semaforo dal sistema
        }

        if (sem_confirmations[i] != SEM_FAILED) {
            sem_close(sem_confirmations[i]);
            // Chiude il semaforo di conferma

            char name[64];
            sprintf(name, "%s%d", SEM_CONFIRMATION_BASE, i);
            sem_unlink(name);
            // Rimuove il semaforo dal filesystem 
        }
    }
}

int main(void) {

    /* Installazione SIGTERM*/
    struct sigaction sa;
    sa.sa_handler = gestore_sigterm;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    if (sigaction(SIGTERM, &sa, NULL) == -1) {
        perror("[Incrocio] sigaction");
        exit(EXIT_FAILURE);
    }

    // Crea la FIFO principale per ricevere i dati dal garage
    mkfifo(fifoGarageToIncrocio, 0666);

    /* Pulizia preventiva per sicurezza */
    for (int i = 0; i < NUM_AUTO; i++) {
        char name_perm[64], name_conf[64];
        sprintf(name_perm, "%s%d", SEM_PERMISSION_BASE, i);
        sprintf(name_conf, "%s%d", SEM_CONFIRMATION_BASE, i);
        
        sem_unlink(name_perm);
        sem_unlink(name_conf);
    }

    /* Creazione dei semafori */
    for (int i = 0; i < NUM_AUTO; i++) {

        char name_perm[64], name_conf[64];
        sprintf(name_perm, "%s%d", SEM_PERMISSION_BASE, i);
        sprintf(name_conf, "%s%d", SEM_CONFIRMATION_BASE, i);
        
        sem_permissions[i] = sem_open(name_perm, O_CREAT | O_EXCL, 0666, 0);
        sem_confirmations[i] = sem_open(name_conf, O_CREAT | O_EXCL, 0666, 0);

        if (sem_permissions[i] == SEM_FAILED || sem_confirmations[i] == SEM_FAILED) {
            perror("[Incrocio] sem_open creation");
            cleanup_resources();
            exit(EXIT_FAILURE);
        }
    }


    // Attesa passiva del file garage.pid 
    while (access("garage.pid", F_OK) == -1) {
        sleep(1);
    }

    // Legge il PID del garage 
    FILE *fp = fopen("garage.pid", "r");
         if (!fp) {
             perror("[Incrocio] fopen garage.pid");
             exit(EXIT_FAILURE);
         }

         fscanf(fp, "%d", &pidGarage);
         fclose(fp);

    printf("[Incrocio] Avviato (PID garage = %d)\n", pidGarage);


    while (!termina) {

        int fd = open(fifoGarageToIncrocio, O_RDONLY);  // Apre la FIFO in lettura
        if (fd == -1) {
            if (errno == EINTR && termina) break;
            perror("[Incrocio] open fifoGarageToIncrocio");
            continue;
        }

        ssize_t n = read(fd, direzioni, sizeof(direzioni));  // Legge le direzioni delle 4 automobili
        close(fd);

        if (n != sizeof(direzioni)) {
            if (termina) break;
            fprintf(stderr, "[Incrocio] Errore lettura direzioni\n");
            continue;
        }

        printf("\n[Incrocio] Ricevute 4 automobili al quadrivio\n");

        /* Scelta dell’auto che può passare */
        for (int passate = 0; passate < NUM_AUTO && !termina; passate++) {

            int iAuto = GetNextCar(direzioni);
            if (iAuto == NESSUNA_AUTO) break;

            /* Scrittura su incrocio.txt */
            int fd_file = open("incrocio.txt", O_WRONLY | O_CREAT | O_APPEND, 0666);
            if (fd_file == -1) {
                perror("[Incrocio] open incrocio.txt");
                exit(EXIT_FAILURE);
            }

            char buf[16];
            int len = snprintf(buf, sizeof(buf), "%d\n", iAuto);
            write(fd_file, buf, len);
            close(fd_file);

            printf("\033[33m[Incrocio] Auto %d passa e svolta verso %d\033[0m\n", iAuto, direzioni[iAuto]);


            // Concede il permesso all’automobile di attraversare
            sem_post(sem_permissions[iAuto]);


            // Incrocio attende che l’auto segnali la fine della traversata
            while (sem_wait(sem_confirmations[iAuto]) == -1) {
                if (errno == EINTR) {
                    continue;
                } else {
                    perror("[Incrocio] sem_wait confirmation");
                     break;
            }
        }
            direzioni[iAuto] = NESSUNA_AUTO;
        }
    }


    /* Terminazione */
    printf("\033[32m\n[Incrocio] Terminazione in corso...\033[0m\n");

    // Invia il segnale di terminazione al garage
    if (pidGarage > 0) {
        kill(pidGarage, SIGTERM);
        waitpid(pidGarage, NULL, 0);   // incrocio attende la fine del garage
    }

    // Pulizia delle risorse 
    cleanup_resources();

    printf("[Incrocio] Terminato correttamente (ultimo processo).\n");
    return EXIT_SUCCESS;
}
