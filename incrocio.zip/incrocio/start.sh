#!/bin/bash   
# indica che lo script deve essere eseguito usando la shell Bash

echo "=============================="
echo "   COMPILAZIONE DEL PROGETTO  "
echo -e "==============================\n"

# Pulizia file di output precedenti
rm -f auto.txt incrocio.txt

# Rileva il sistema operativo
# ****** HO INSERITO QUESTA RILEVAZIONE DEL S.O PERCHé IO USO UN macOS ******
OS=$(uname)

# Imposta il flag corretto per la compilazione
if [[ "$OS" == "Darwin" ]]; then
# Caso macOS
  echo " SISTEMA RILEVATO: macOS"
  LIBRT=""      # macOS non usa -lrt
else
# Caso Linux
  echo " SISTEMA RILEVATO: Linux"
  LIBRT="-lrt"
# Su Linux è necessario linkare la libreria realtime per i semafori POSIX
fi

# Compilazione dei file
gcc -o incrocio incrocio.c $LIBRT
gcc -o garage garage.c $LIBRT
gcc -o automobile automobile.c $LIBRT

# Controllo errori di compilazione
if [[ $? -ne 0 ]]; then
  echo " Errore durante la compilazione. Controlla i file .c"
  exit 1
fi

echo -e " Compilazione completata con successo.\n"

# Gestione delle FIFO 
FIFO_GARAGE_TO_INCROCIO="fifo_garage_to_incrocio"

echo " Pulizia vecchie FIFO..."
rm -f "$FIFO_GARAGE_TO_INCROCIO"
# Rimuove eventuali FIFO residue da esecuzioni precedenti

echo -e " Creazione nuova FIFO principale...\n"
mkfifo "$FIFO_GARAGE_TO_INCROCIO"

#  Avvio dei processi 
echo " Avvio del processo incrocio..."
./incrocio &
# Avvia il processo incrocio in background

PID_INCROCIO=$!
# $! contiene il PID dell’ultimo processo avviato in background
# Serve per attendere la sua terminazione

sleep 1

echo -e " Avvio del processo garage...\n"
./garage &

# Attesa la terminazione del processo incrocio
wait $PID_INCROCIO

# Pulizia finale
echo -e " Pulizia finale...\n"
# Rimuove tutte le FIFO create durante l’esecuzione
rm -f "$FIFO_GARAGE_TO_INCROCIO"

echo -e " Applicazione terminata.\n"


